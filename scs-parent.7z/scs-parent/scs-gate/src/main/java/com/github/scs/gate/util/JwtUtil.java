package com.github.scs.gate.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class JwtUtil {

    @Value("${jwt.security.secret}")
    private String jwtKey;

    @Value("${jwt.security.expired-time-in}")
    private Integer expiredTimeIn;

    /**
     * 生成令牌
     */
    public String createToken(String code) {
        Map<String, Date> dateMap = calExpiredTime();
        return JWT.create()
                .withClaim("code", code)
                .withExpiresAt(dateMap.get("expiredTime"))
                .withIssuedAt(dateMap.get("now"))
                .sign(Algorithm.HMAC256(jwtKey));
    }

    /**
     * 获取自定义数据
     */
    public String getValue(String token) {
        try {
            DecodedJWT dj = JWT.require(Algorithm.HMAC256(jwtKey)).build().verify(token);
            return dj.getClaim("code").asString();
        } catch (Exception e) {
            log.warn(e.getMessage() + " [{}]", token);
            return StringUtils.EMPTY;
        }
    }

    /**
     * 验证Token
     */
    public boolean verifyToken(String token) {
        try {
            JWT.require(Algorithm.HMAC256(jwtKey)).build().verify(token);
        } catch (JWTVerificationException e) {
            log.warn(e.getMessage() + " [{}]", token);
            return false;
        }
        return true;
    }

    /**
     * 计算过期时间
     */
    private Map<String, Date> calExpiredTime() {
        Map<String, Date> map = new HashMap<>();
        Calendar calendar = Calendar.getInstance();
        Date now = calendar.getTime();
        calendar.add(Calendar.SECOND, expiredTimeIn);
        map.put("now", now); // 当前时间
        map.put("expiredTime", calendar.getTime()); // 过期时间
        return map;
    }
}
