package com.github.scs.gate.security;

import cn.hutool.core.collection.CollUtil;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 用于根据用户名获取用户信息
 */
@Component
public class MyUserDetailsService implements UserDetailsService {
    private static final Map<String, Set<String>> map = new HashMap<>();

    @PostConstruct
    public void init() {
        map.put("tf", CollUtil.newHashSet("report", "me:test"));
        map.put("qq", CollUtil.newHashSet("report"));
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (!map.containsKey(username)) {
            throw new UsernameNotFoundException(username);
        }
        return new MyUserDetails(username, map.get(username));
    }
}
