package com.github.scs.auth.mapper;

import com.github.scs.auth.model.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 用户角色表 Mapper 接口
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Mapper
public interface UserRoleMapper extends BaseMapper<UserRole> {

}
