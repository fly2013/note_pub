package com.github.scs.auth.service;

import com.github.scs.auth.model.entity.RoleResource;
import com.github.scs.auth.mapper.RoleResourceMapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 角色资源权限表 服务实现类
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Service
public class RoleResourceService extends ServiceImpl<RoleResourceMapper, RoleResource> {

}
