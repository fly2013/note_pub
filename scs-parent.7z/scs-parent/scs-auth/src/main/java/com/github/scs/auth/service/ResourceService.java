package com.github.scs.auth.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.scs.auth.mapper.ResourceMapper;
import com.github.scs.auth.model.entity.Resource;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 前后端分离资源权限表 服务实现类
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Service
public class ResourceService extends ServiceImpl<ResourceMapper, Resource> {

    public Set<String> selectApiList() {
        return this.list().stream().map(Resource::getUri)
                .filter(StringUtils::isNotEmpty)
                .collect(Collectors.toSet());
    }

}
