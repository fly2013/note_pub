package com.github.scs.auth.mapper;

import com.github.scs.auth.model.entity.RoleResource;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 角色资源权限表 Mapper 接口
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Mapper
public interface RoleResourceMapper extends BaseMapper<RoleResource> {

}
