package com.github.scs.auth.controller;

import com.github.scs.auth.service.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

/**
 * <p>
 * 前后端分离资源权限表 前端控制器
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@RestController
@RequestMapping("resource")
public class ResourceController {
    @Autowired
    private ResourceService resourceService;

    @PostMapping("selectApiList")
    public Set<String> selectApiList() {
        return resourceService.selectApiList();
    }

}
