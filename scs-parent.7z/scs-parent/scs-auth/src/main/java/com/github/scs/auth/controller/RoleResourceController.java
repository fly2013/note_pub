package com.github.scs.auth.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 角色资源权限表 前端控制器
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@RestController
@RequestMapping("/roleResource")
public class RoleResourceController {

}
