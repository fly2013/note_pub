package com.github.scs.gate.util;

import cn.hutool.json.JSONUtil;
import lombok.Data;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Data
public class Results {
    public static final Results R_000 = new Results("000", "success");
    public static final Results R_001 = new Results("001", "未登录或token已失效");

    public static final Results R_999 = new Results("999", "没有访问权限");

    private String code;
    private String msg;

    private Results(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static Results ok() {
        return R_000;
    }

    public void write(HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        response.getWriter().println(JSONUtil.toJsonStr(this));
        response.getWriter().flush();
    }
}
