package com.github.scs.gate;

import com.github.scs.gate.feign.AuthClient;
import com.github.scs.gate.util.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class TestController {
    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthClient authClient;

    @GetMapping("token")
    public String token(String code) {
        return jwtUtil.createToken(code);
    }

    @GetMapping("hello")
    @PreAuthorize("hasAuthority('me:test')")
    public String hello() {
        log.info("api: " + authClient.selectApiList());
        return "hello, auth test";
    }
}
