package com.github.scs.gate.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

@Component("ac")
@Slf4j
public class AuthCheck {

    // 只需要登录就能访问的接口地址
    private static final Set<String> URL = new HashSet<>();
    // 需要区分角色的接口地址  用户名称：接口地址
    private static final HashMap<String, Set<String>> URL_MAP = new HashMap();

    static {
        URL.add("/biz/project/list");

        Set<String> tfSet = new HashSet<>();
        tfSet.add("/biz/user/list");
        tfSet.add("/biz/report/list");
        URL_MAP.put("tf", tfSet);

        Set<String> qqSet = new HashSet<>();
        qqSet.add("/biz/report/list");
        URL_MAP.put("qq", qqSet);
    }

    public boolean hasPermit(HttpServletRequest req, Authentication auth) {
        log.info("--------------hasPermit------------------" + req.getRequestURL());
        Object principal = auth.getPrincipal();
        String reqURI = req.getRequestURI();
        AntPathMatcher matcher = new AntPathMatcher();
        // 有一些接口是不需要权限，只要登录就能访问的，比如一些省市区接口
        boolean result = URL.stream().anyMatch(url -> matcher.match(url, reqURI));
        if (result) {
            return true;
        }
        //这里使用的是定义在内存的用户信息
        if (principal instanceof MyUserDetails) {
            MyUserDetails userDetails = (MyUserDetails) principal;
            // 可以根据用户id或者用户名从redis中获得用户拥有的菜单权限url
            String username = userDetails.getUsername();
            log.info("username=" + username);
            Set<String> urlSet = URL_MAP.get(username);
            return urlSet.stream().anyMatch(u -> matcher.match(u, reqURI));
        }
        return false;
    }
}
