package com.github.scs.auth.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 前后端分离资源权限表
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Getter
@Setter
@TableName("t_scs_resource")
public class Resource implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 类别 0.目录 1.页面 2.按钮
     */
    private Boolean category;

    /**
     * 父id
     */
    private Long parentId;

    /**
     * 资源名称
     */
    private String title;

    /**
     * api鉴权接口
     */
    private String uri;

    /**
     * 按钮权限标志
     */
    private String label;

    /**
     * route名称
     */
    private String name;

    /**
     * route路径
     */
    private String path;

    /**
     * 资源类型 BACK FRONT
     */
    private String resType;
}
