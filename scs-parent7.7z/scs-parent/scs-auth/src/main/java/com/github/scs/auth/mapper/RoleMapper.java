package com.github.scs.auth.mapper;

import com.github.scs.auth.model.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 系统角色表 Mapper 接口
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@Mapper
public interface RoleMapper extends BaseMapper<Role> {

}
