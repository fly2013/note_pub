package com.github.scs.auth.controller;

import cn.hutool.json.JSONUtil;
import com.github.scs.auth.service.ResourceService;
import com.github.scs.common.UserHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

/**
 * <p>
 * 前后端分离资源权限表 前端控制器
 * </p>
 *
 * @author tf
 * @since 2023-04-30
 */
@RestController
@RequestMapping("resource")
@Slf4j
public class ResourceController {
    @Autowired
    private ResourceService resourceService;

    @PostMapping("selectApiList")
    public Set<String> selectApiList() {
        log.info("hashCode=" + Thread.currentThread().hashCode());
        log.info("user=" + JSONUtil.toJsonStr(UserHolder.getUser()));
        log.info("getNotesName=" + UserHolder.getUser().getNotesName());
        return resourceService.selectApiList();
    }

}
