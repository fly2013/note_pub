package com.github.scs.auth;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.config.rules.DbColumnType;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import org.apache.ibatis.annotations.Mapper;

import java.sql.Types;
import java.util.Collections;

public class CodeGenerator {
    public static void main(String[] args) {
        String dir = "C:/dev/Java/work/scs/scs-parent/scs-auth/src/main";
        FastAutoGenerator root = FastAutoGenerator.create("jdbc:mysql://localhost:3306/scs", "scs", "123456");
        root.globalConfig(builder -> {
            builder.author("tf") // 设置作者
                    .disableOpenDir()
                    .disableServiceInterface()
                    .outputDir(dir + "/java"); // 指定输出目录
        });
        root.dataSourceConfig(builder -> builder.typeConvertHandler((globalConfig, typeRegistry, metaInfo) -> {
            int typeCode = metaInfo.getJdbcType().TYPE_CODE;
            if (typeCode == Types.SMALLINT) { // 自定义类型转换
                return DbColumnType.INTEGER;
            }
            return typeRegistry.getColumnType(metaInfo);
        }));
        root.packageConfig(builder -> {
            builder
                    .parent("com.github.scs.auth")
                    .serviceImpl("service")
                    .entity("model.entity")
                    .pathInfo(Collections.singletonMap(OutputFile.xml, dir + "/resources/mapper")); // 设置mapperXml生成路径
        });
        root.strategyConfig(builder -> {
            builder
                    .addInclude("t_scs_user", "t_scs_user_role") // 设置需要生成的表名
                    .addTablePrefix("t_scs_") // 设置过滤表前缀
                    .controllerBuilder().enableRestStyle()
                    .serviceBuilder().convertServiceImplFileName(entityName -> entityName + "Service")
                    .mapperBuilder().mapperAnnotation(Mapper.class)
                    .entityBuilder().enableLombok();
        });
        root.templateEngine(new FreemarkerTemplateEngine());
        root.execute();// 使用Freemarker引擎模板，默认的是Velocity引擎模板
    }
}
