package com.github.scs.common;

import cn.hutool.json.JSONUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

@Slf4j
public class FeignUserFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        this.initUserInfo((HttpServletRequest) request);
        chain.doFilter(request, response);
    }

    private void initUserInfo(HttpServletRequest request) {
        String json = request.getHeader("USER_IN_HEADER");
        log.info("-----initUserInfo-------" + json);
        if (!StringUtils.isEmpty(json)) {
            json = URLDecoder.decode(json, StandardCharsets.UTF_8);
            MyUser user = JSONUtil.toBean(json, MyUser.class);
            //将用户信息放入上下文中
            UserHolder.setUser(user);
        }
    }
}
