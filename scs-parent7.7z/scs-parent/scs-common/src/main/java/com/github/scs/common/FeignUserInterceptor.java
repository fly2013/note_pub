package com.github.scs.common;

import cn.hutool.json.JSONUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Slf4j
public class FeignUserInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
        //从应用上下文中取出user信息，放入Feign的请求头中
        MyUser user = UserHolder.getUser();
        log.info("-----apply-------" + user);
        if (user != null) {
            String json = JSONUtil.toJsonStr(user);//URLEncoder.encode(json, StandardCharsets.UTF_8)
            template.header("USER_IN_HEADER", URLEncoder.encode(json, StandardCharsets.UTF_8));
        }
    }
}
