package com.github.scs.common;

import lombok.Data;

@Data
public class MyUser {

    private Long id;

    private String notesId;

    private String notesName;

    private Long tenantId;

    private String tenantName;

    private String domainUrl;

}
