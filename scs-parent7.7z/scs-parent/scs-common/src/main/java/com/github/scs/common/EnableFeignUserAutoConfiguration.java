package com.github.scs.common;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EnableFeignUserAutoConfiguration {
    @Bean
    public FeignUserInterceptor feignUserInterceptor() {
        return new FeignUserInterceptor();
    }

    @Bean
    public FeignUserFilter feignUserFilter() {
        return new FeignUserFilter();
    }
}
