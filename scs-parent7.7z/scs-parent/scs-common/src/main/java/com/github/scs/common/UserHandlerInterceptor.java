package com.github.scs.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
public class UserHandlerInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        log.info("request.getRequestURI()=" + request.getRequestURI());
        log.info("preHandle=" + request.getRequestURL());
        String notesId = request.getHeader("NOTES_ID");
        log.info("notesId=" + notesId);
        if (!StringUtils.isEmpty(notesId)) {
            MyUser user = new MyUser();
            user.setId(99L);
            user.setNotesId(notesId);
            user.setNotesName("糖糖");
            user.setTenantId(28L);
            UserHolder.setUser(user);
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        log.info("postHandle=" + request.getRequestURL());
        log.info("postHandle getNotesName=" + UserHolder.getUser().getNotesName());
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("afterCompletion=" + request.getRequestURL());
        log.info("afterCompletion getNotesName=" + UserHolder.getUser().getNotesName());
        UserHolder.remove();
        log.info("afterCompletion getNotesName=" + UserHolder.getUser().getNotesName());
    }
}
