package com.github.scs.common;

public class UserHolder {

    private static final ThreadLocal<MyUser> USER_INFO = ThreadLocal.withInitial(MyUser::new);

    private UserHolder() {
    }

    public static MyUser getUser() {
        return USER_INFO.get();
    }

    public static void setUser(MyUser user) {
        USER_INFO.set(user);
    }

    public static void remove() {
        USER_INFO.remove();
    }
}
