package com.github.scs.biz;

import cn.hutool.json.JSONUtil;
import com.github.scs.common.UserHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

@RestController
@RequestMapping("report")
@Slf4j
public class ReportController {

    @PostMapping("list")
    public String list(HttpServletRequest request) {
        log.info("---report---list---" + request.getHeader("NOTES_ID"));
        log.info("---report---getRemoteHost---" + request.getRemoteHost());
        log.info("---report---getRemoteAddr---" + request.getRemoteAddr());
        Enumeration<String> names = request.getHeaderNames();
        while (names.hasMoreElements()) {
            String head = names.nextElement();
            log.info(head + "--" + request.getHeader(head));
        }
        return "hi, report-list";
    }

    @Autowired
    private TestClient testClient;

    @PostMapping("search")
    public String search() {
        log.info("hashCode=" + Thread.currentThread().hashCode());
        log.info("user=" + JSONUtil.toJsonStr(UserHolder.getUser()));
        log.info("getNotesName=" + UserHolder.getUser().getNotesName());
        log.info("---report---search---" + testClient.selectApiList());
        return "hi, report-search";
    }
}
