package com.github.scs.biz;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Set;

@FeignClient(value = "scs-auth", contextId = "auth")
public interface TestClient {

    @PostMapping("resource/selectApiList")
    Set<String> selectApiList();
}
